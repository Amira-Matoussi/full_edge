from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
import os
import logging
from typing import Dict, Any, List, Optional
from llama_cpp import Llama
import uuid
from datetime import datetime, timedelta
import threading
import time

# =========================
# Session memory store
# =========================
session_memory = {}
memory_lock = threading.Lock()

# =========================
# Utility functions
# =========================
def extract_name(input_text: str) -> str:
    import re
    patterns = [
        r'my name is (\w+)',
        r"i'm (\w+)",
        r'i am (\w+)',
        r'call me (\w+)',
        r'this is (\w+)'
    ]
    for pattern in patterns:
        match = re.search(pattern, input_text, re.IGNORECASE)
        if match:
            return match.group(1)
    return None

def extract_issue_type(input_text: str) -> str:
    import re
    issue_patterns = [
        (r'billing|bill|payment|charge|invoice', 'billing'),
        (r'internet|wifi|connection|slow|outage', 'internet'),
        (r'phone|mobile|call|text|sms', 'mobile'),
        (r'technical|support|help|problem|issue', 'technical'),
        (r'account|login|password|profile', 'account')
    ]
    for pattern, issue_type in issue_patterns:
        if re.search(pattern, input_text, re.IGNORECASE):
            return issue_type
    return None

def build_prompt_with_memory(memory: dict, current_input: str, system_message: str) -> str:
    contextual_prompt = system_message
    if memory.get('userName') or memory.get('issueType') or memory.get('history'):
        contextual_prompt += "\n\nConversation Context:"
        if memory.get('userName'):
            contextual_prompt += f"\nUser name: {memory['userName']}"
        if memory.get('issueType'):
            contextual_prompt += f"\nIssue type: {memory['issueType']}"
        if memory.get('history'):
            contextual_prompt += "\nPrevious conversation:"
            for turn in memory['history'][-3:]:
                contextual_prompt += f"\nUser: {turn['user']}"
                contextual_prompt += f"\nAssistant: {turn['ai']}"
        contextual_prompt += f"\n\nCurrent user input: {current_input}"
        contextual_prompt += "\nRespond appropriately using the context above."
    return contextual_prompt

def cleanup_expired_sessions():
    while True:
        try:
            with memory_lock:
                now = datetime.now()
                expired_sessions = []
                for session_id, session_data in session_memory.items():
                    if now - session_data['lastUpdated'] > timedelta(minutes=30):
                        expired_sessions.append(session_id)
                for session_id in expired_sessions:
                    del session_memory[session_id]
                    logger.info(f"Cleaned up expired session: {session_id}")
            time.sleep(60)
        except Exception as e:
            logger.error(f"Error in cleanup thread: {e}")
            time.sleep(60)

# Start cleanup thread
cleanup_thread = threading.Thread(target=cleanup_expired_sessions, daemon=True)
cleanup_thread.start()

# =========================
# Logging
# =========================
logging.basicConfig(level=logging.DEBUG)  # Set to DEBUG for detailed logs
logger = logging.getLogger(__name__)

# =========================
# FastAPI app
# =========================
app = FastAPI(title="Local LLM Server")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =========================
# Request models
# =========================
class ConversationTurn(BaseModel):
    user: str
    ai: str

class TranscriptionRequest(BaseModel):
    transcription: str
    history: Optional[List[ConversationTurn]] = []
    mode: str = "local"
    language: str = "en-US"
    sessionId: Optional[str] = None

# =========================
# Global variables
# =========================
model = None
tokenizer = None

MODEL_PATH = r"C:\Users\mira\.llama\checkpoints\Llama-2-7b-chat"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MAX_LENGTH = 100
TEMPERATURE = 0.7

# =========================
# Startup event: Load model
# =========================
@app.on_event("startup")
async def startup_event():
    global model, tokenizer
    try:
        logger.info(f"Loading Llama-2 model from {MODEL_PATH} on {DEVICE} ...")
  
        # Check that folder exists
        if not os.path.exists(MODEL_PATH):
            logger.error(f"Model path does not exist: {MODEL_PATH}")
            model = None
            tokenizer = None
            return

        # Load tokenizer
        tokenizer_files = ["tokenizer.model", "tokenizer.json"]
        tokenizer_file_exists = any(os.path.exists(os.path.join(MODEL_PATH, f)) for f in tokenizer_files)
        if tokenizer_file_exists:
            tokenizer = LlamaTokenizer.from_pretrained(MODEL_PATH, local_files_only=True)
            logger.info("Tokenizer loaded successfully.")
        else:
            tokenizer = None
            logger.warning("Tokenizer files not found, proceeding without tokenizer.")

        # Load raw Llama-2 PyTorch model
        # (Your folder contains consolidated.00.pth + params.json)
        model = LlamaForCausalLM.from_pretrained(
            MODEL_PATH,
            torch_dtype=torch.float16 if DEVICE == "cuda" else torch.float32,
            device_map="auto" if DEVICE == "cuda" else None,
            low_cpu_mem_usage=True,
            local_files_only=True
        )
        model.eval()
        logger.info(f"Model loaded successfully: {type(model)}")
        logger.info(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")

    except Exception as e:
        logger.error(f"Error loading model: {str(e)}")
        model = None
        tokenizer = None



# =========================
# Process voice
# =========================
@app.post("/api/voice-pipeline")
async def process_voice(request: TranscriptionRequest):
    if model is None or tokenizer is None:
        raise HTTPException(status_code=500, detail="Model not loaded. Check server logs.")
    
    try:
        transcription = request.transcription
        history = request.history
        language = request.language
        session_id = request.sessionId or str(uuid.uuid4())

        logger.info(f"Session ID: {session_id}")
        logger.info(f"Current transcription: {transcription}")

        with memory_lock:
            if session_id not in session_memory:
                session_memory[session_id] = {
                    'userName': None,
                    'issueType': None,
                    'history': [],
                    'lastUpdated': datetime.now(),
                    'language': language
                }

            memory = session_memory[session_id]
            memory['lastUpdated'] = datetime.now()
            memory['language'] = language

            extracted_name = extract_name(transcription)
            if extracted_name:
                memory['userName'] = extracted_name
            extracted_issue_type = extract_issue_type(transcription)
            if extracted_issue_type:
                memory['issueType'] = extracted_issue_type

        logger.info(f"Extracted user name: {extracted_name}")
        logger.info(f"Extracted issue type: {extracted_issue_type}")
        logger.debug(f"Session memory before generating response: {memory}")

        if language == "fr-FR":
            system_message = """Votre nom est Slah, un agent de support client télécom. RÉPONDEZ TOUJOURS EN FRANÇAIS. Gardez les réponses COURTES (1-2 phrases max)..."""
        elif language == "ar-SA":
            system_message = """اسمك صلاح، وكيل دعم عملاء اتصالات. أجب دائمًا باللغة العربية. اجعل الردود قصيرة (جملة أو جملتين كحد أقصى)..."""
        else:
            system_message = """Your name is Slah, a telecom customer support agent. ALWAYS respond in English. Keep responses SHORT (1-2 sentences max)..."""

        enriched_prompt = build_prompt_with_memory(memory, transcription, system_message)
        messages_for_llm = [{"role": "system", "content": enriched_prompt}]
        recent_history = memory['history'][-5:] if memory['history'] else []
        for turn in recent_history:
            messages_for_llm.append({"role": "user", "content": turn['user']})
            messages_for_llm.append({"role": "assistant", "content": turn['ai']})
        messages_for_llm.append({"role": "user", "content": transcription})

        logger.debug(f"Enriched prompt:\n{enriched_prompt}")
        logger.debug(f"Messages sent to model:\n{messages_for_llm}")

        ai_response = ""

        if "GGUF" in MODEL_PATH and isinstance(model, Llama):
            chat_completion = model.create_chat_completion(
                messages=messages_for_llm,
                max_tokens=MAX_LENGTH,
                temperature=TEMPERATURE,
                stop=["</s>", "[INST]"]
            )
            ai_response = chat_completion["choices"][0]["message"]["content"].strip()
        else:
            if tokenizer and hasattr(tokenizer, 'apply_chat_template'):
                prompt = tokenizer.apply_chat_template(messages_for_llm, tokenize=False, add_generation_prompt=True)
            else:
                prompt_parts = []
                for msg in messages_for_llm:
                    if msg["role"] == "system":
                        prompt_parts.append(f"System: {msg['content']}\n")
                    elif msg["role"] == "user":
                        prompt_parts.append(f"User: {msg['content']}\n")
                    elif msg["role"] == "assistant":
                        prompt_parts.append(f"Assistant: {msg['content']}\n")
                prompt = "".join(prompt_parts)
                prompt += "Assistant:"

            logger.debug(f"Constructed HF prompt: {prompt}")
            inputs = tokenizer(prompt, return_tensors="pt").to(DEVICE)
            outputs = model.generate(
                **inputs,
                max_new_tokens=MAX_LENGTH,
                temperature=TEMPERATURE,
                do_sample=True,
                top_p=0.95,
            )
            ai_response = tokenizer.decode(outputs[0], skip_special_tokens=True)
            if "[/INST]" in ai_response:
                ai_response = ai_response.split("[/INST]")[-1].strip()
            elif "Assistant:" in ai_response:
                ai_response = ai_response.split("Assistant:")[-1].strip()

        with memory_lock:
            memory['history'].append({'user': transcription, 'ai': ai_response})

        logger.info(f"AI Response (raw): {ai_response}")
        logger.debug(f"Session memory after response: {memory}")

        return {
            "transcription": transcription,
            "aiResponse": ai_response,
            "sessionId": session_id,
            "memoryContext": {
                "userName": memory.get('userName'),
                "issueType": memory.get('issueType'),
                "conversationLength": len(memory.get('history', []))
            }
        }
    except Exception as e:
        logger.error(f"Error generating response: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error generating response: {str(e)}")

# =========================
# Config check
# =========================
@app.get("/api/check-config")
async def check_config():
    return {
        "hasLocalModel": model is not None,
        "modelPath": MODEL_PATH,
        "device": DEVICE,
        "modelLoaded": model is not None
    }

# =========================
# Run server
# =========================
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("local_llm_server:app", host="0.0.0.0", port=8000, reload=True)